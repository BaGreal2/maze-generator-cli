#include "displayManager.hpp"
#include <string>
#include <vector>

using std::string, std::vector;

class FileManager {
private:
  string directoryPath = "./saved";
  DisplayManager display;

public:
  FileManager();
  int createSaveDirectory();
  int save(string name, string data);
  string read(string name);
  vector<string> getSavedFilesNames();
};
