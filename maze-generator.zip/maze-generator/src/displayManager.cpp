#include "../include/displayManager.hpp"
#include <chrono>
#include <cstdlib>
#include <iostream>
#include <thread>

DisplayManager::DisplayManager() {}

void DisplayManager::clearScreen() { std::cout << "\033[2J\033[1;1H"; }

void DisplayManager::displayFrame(string frame, string mode) {
  if (mode == "maze") {
    for (char ch : frame) {
      switch (ch) {
      case '#': {
        std::cout << red(string(1, ch));
        break;
      }
      case '.': {
        std::cout << blue(string(1, ch));
        break;
      }
      case '+': {
        std::cout << yellow(string(1, ch));
        break;
      }
      case 'F':
      case 'S': {
        std::cout << yellow(string(1, ch));
        break;
      }
      default: {
        std::cout << ch;
        break;
      }
      }
    }
  } else if (mode == "red") {
    std::cout << red(frame);
  } else if (mode == "blue") {
    std::cout << blue(frame);
  } else if (mode == "green") {
    std::cout << green(frame);
  } else if (mode == "yellow") {
    std::cout << yellow(frame);
  } else {
    std::cout << frame;
  }
}

void DisplayManager::sleep(int ms) {
  std::this_thread::sleep_for(std::chrono::milliseconds(ms));
}

string DisplayManager::red(string text) {
  return "\033[1;31m" + text + "\033[0m";
}
string DisplayManager::blue(string text) {
  return "\033[1;34m" + text + "\033[0m";
}
string DisplayManager::green(string text) {
  return "\033[1;32m" + text + "\033[0m";
}
string DisplayManager::yellow(string text) {
  return "\033[1;33m" + text + "\033[0m";
}
